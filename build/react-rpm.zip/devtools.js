chrome.devtools.panels.create('react-rpm',
  null,
  'devpanel.html',
  () => {
  }
);